

    public class StrategyPatternDemo {
   public static void main(String[] args) {
       String Name= "Alex";
       int n=3;
       switch (n) {
  case 1:
    Context context = new Context(new Spear());		
       
      context.executeStrategy(Name);
    break;
  case 2:
   
      context = new Context(new Sword());		
      context.executeStrategy(Name);
    break;
  case 3:
      context = new Context(new shield());		
      context.executeStrategy(Name);
        break;
   default:
    System.out.println("opps try again");
    
}
      
       


    
   }
}

